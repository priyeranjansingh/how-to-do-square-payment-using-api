<?php
require 'vendor/autoload.php';
// dotenv is used to read from the '.env' file created for credentials
$dotenv = Dotenv\Dotenv::create(__DIR__);
$dotenv->load();
?>
<!-- link to the SqPaymentForm library -->
<script type="text/javascript" src=
<?php
	echo "\"";
	echo ($_ENV["USE_PROD"] == 'true')  ?  "https://js.squareup.com/v2/paymentform"
										:  "https://js.squareupsandbox.com/v2/paymentform";
	echo "\"";
?>
></script>
<script type="text/javascript">
window.applicationId =
  <?php
	echo "\"";
	echo ($_ENV["USE_PROD"] == 'true')  ?  $_ENV["PROD_APP_ID"]
										:  $_ENV["SANDBOX_APP_ID"];
	echo "\"";
  ?>;
window.locationId =
<?php
  echo "\"";
  echo ($_ENV["USE_PROD"] == 'true')  ?  $_ENV["PROD_LOCATION_ID"]
									  :  $_ENV["SANDBOX_LOCATION_ID"];
  echo "\"";
?>;
</script>

<!-- link to the local SqPaymentForm initialization -->
<script type="text/javascript" src="<?php echo site_url()."/custom_one_time/js/sq-payment-form.js"?>"></script>
<!-- link to the custom styles for SqPaymentForm -->
<link rel="stylesheet" type="text/css" href="<?php echo site_url()."/custom_one_time/css/sq-payment-form.css"?>">
<!-- Begin Payment Form -->
<style>
.sq-payment-form {
    margin: auto !important;
}
</style>
<?php
if(isset($_POST['paypal_amount'])){
	$amount=$_POST['paypal_amount']*100;
	$host_url = ($_ENV["USE_PROD"] == 'true')  ?  "https://connect.squareup.com":"https://connect.squareupsandbox.com";
	$access_token = ($_ENV["USE_PROD"] == 'true')  ?  $_ENV["PROD_ACCESS_TOKEN"]:$_ENV["SANDBOX_ACCESS_TOKEN"];
	$api_config = new \SquareConnect\Configuration();
	$api_config->setHost($host_url);
	# Initialize the authorization for Square
	$api_config->setAccessToken($access_token);
	$api_client = new \SquareConnect\ApiClient($api_config);
	
	# Helps ensure this code has been reached via form submission
	if ($_SERVER['REQUEST_METHOD'] != 'POST') {
	  error_log("Received a non-POST request");
	  echo "Request not allowed";
	  http_response_code(405);
	  return;
	}

	# Fail if the card form didn't send a value for `nonce` to the server
	$nonce = $_POST['nonce'];
	if (is_null($nonce)) {
	  echo "Invalid card data";
	  http_response_code(422);
	  return;
	}

	$payments_api = new \SquareConnect\Api\PaymentsApi($api_client);
	
	# To learn more about splitting payments with additional recipients,
	# see the Payments API documentation on our [developer site]
	# (https://developer.squareup.com/docs/payments-api/overview).
	$request_body = array (
	  "source_id" => $nonce,
	  # Monetary amounts are specified in the smallest unit of the applicable currency.
	  # This amount is in cents. It's also hard-coded for $1.00, which isn't very useful.
	  "amount_money" => array (
		"amount" => $amount,
		"currency" => "USD"
	  ),
	  # Every payment you process with the SDK must have a unique idempotency key.
	  # If you're unsure whether a particular payment succeeded, you can reattempt
	  # it with the same idempotency key without worrying about double charging
	  # the buyer.
	  "idempotency_key" => uniqid()
	);
	try {
		$result = $payments_api->createPayment($request_body);
		print_r($result->getpayment()->getid());
		echo "<pre>";
		print_r($result);
		echo "</pre>";
	} catch (\SquareConnect\ApiException $e) {
	  echo "Caught exception!<br/>";
	  print_r("<strong>Response body:</strong><br/>");
	  echo "<pre>"; var_dump($e->getResponseBody()); echo "</pre>";
	  echo "<br/><strong>Response headers:</strong><br/>";
	  echo "<pre>"; var_dump($e->getResponseHeaders()); echo "</pre>";
	}
}
?>
<div class="sq-payment-form">
<div id="sq-ccbox">
  <form id="nonce-form" novalidate action="" method="post">
	<div class="userDetails">
		<div class="form-style-2-heading">User Details</div>
		<label>
			<span>First Name<span class="required">*</span></span>
			<input type="text" required name="your_name" class="input-field" id="your_name" /> 
			<div id="elmNameError" class="errorMsg"></div>
		</label>
		<label>
			<span>Last Name<span class="required">*</span></span>
			<input type="text" required name="last_name" class="input-field" id="last_name" /> 
			<div id="elmNameError" class="errorMsg"></div>
		</label>
		<label>
			<span>Email<span class="required">*</span></span>
			<input type="text" required name="email" class="input-field" id="email" />
			<div id="elmEmailError" class="errorMsg"></div>
		</label>
		<label>
			<span>Amount(in CAD)<span class="required">*</span></span>
			<input type="text" name="paypal_amount" required class="input-field" id="paypal_amount" />
			<div id="elmPaypalAmountError" class="errorMsg"></div>
		</label>
	</div>
	<div class="sq-field">
	  <label class="sq-label">Card Number</label>
	  <div id="sq-card-number"></div>
	</div>
	<div class="sq-field-wrapper">
	  <div class="sq-field sq-field--in-wrapper">
		<label class="sq-label">CVV</label>
		<div id="sq-cvv"></div>
	  </div>
	  <div class="sq-field sq-field--in-wrapper">
		<label class="sq-label">Expiration</label>
		<div id="sq-expiration-date"></div>
	  </div>
	  <div class="sq-field sq-field--in-wrapper">
		<label class="sq-label">Postal</label>
		<div id="sq-postal-code"></div>
	  </div>
	</div>
	<div class="sq-field">
	  <button id="sq-creditcard" class="sq-button" onclick="onGetCardNonce(event)">
		Pay Now
	  </button>
	</div>
	<!--
	  After a nonce is generated it will be assigned to this hidden input field.
	-->
	<div id="error"></div>
	<input type="hidden" id="card-nonce" name="nonce">
  </form>
</div>
</div>
<!-- End Payment Form -->